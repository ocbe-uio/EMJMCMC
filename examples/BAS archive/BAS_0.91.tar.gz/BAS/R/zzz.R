.First.lib <- function(lib, pkg) {
          library.dynam("BAS", pkg, lib)
        }
